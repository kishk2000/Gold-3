---
name: Gold Live Dark
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#1E293B'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#e9c332'
  on-secondary: '#3b2f00'
  secondary-container: '#c3a000'
  on-secondary-container: '#463800'
  tertiary: '#53e97d'
  on-tertiary: '#003915'
  tertiary-container: '#2ecc64'
  on-tertiary-container: '#005020'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ffe07e'
  secondary-fixed-dim: '#e9c332'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#564500'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
  surface-main: '#0F172A'
  text-primary: '#FFFFFF'
  text-muted: '#94A3B8'
  status-error: '#EF4444'
  status-success: '#22C55E'
typography:
  display-price:
    fontFamily: IBM Plex Sans
    fontSize: 42px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  baseline: 4px
  gutter: 12px
  margin-mobile: 16px
  margin-desktop: 24px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 32px
---

## Brand & Style

This design system is a high-end, dark-mode evolution of a premium financial interface. It adopts a **Corporate Modern** style with **Glassmorphism** and **Tactile** accents to evoke the feeling of a sophisticated institutional trading floor. The brand personality is authoritative, precise, and exclusive, targeting professional investors and high-net-worth individuals.

The aesthetic prioritizes legibility in low-light environments, using deep navy depths to create a sense of infinite space, while "gold-leaf" accents highlight high-value data and primary actions. The visual narrative shifts from traditional banking to a futuristic, data-driven financial hub that feels both secure and cutting-edge.

## Colors

The color palette is built on a foundation of **Deep Navy** and **Charcoal**, providing a low-strain, high-contrast environment for financial monitoring.

- **Primary & Secondary Gold:** Reserved for the most critical information—current asset prices, primary call-to-actions, and active navigation states.
- **Surface Strategy:** The primary background uses `surface-main`. All interactive cards and content groupings reside on `surface-container`.
- **Typography Tiers:** Pure white is used for primary headings and critical data points to ensure maximum "pop" against the dark background. Muted silver is used for secondary labels and metadata to maintain a clean visual hierarchy.
- **Functional Semantics:** Success and error colors are calibrated for dark mode, ensuring they are vibrant enough to be noticed without causing "neon" eye fatigue.

## Typography

The typography system relies on **IBM Plex Sans**, chosen for its technical precision and exceptional legibility in data-heavy environments. 

For financial figures, use **Tabular Lining** figures to ensure that columns of numbers align vertically, which is essential for rapid price comparison. The `display-price` role is the hero of the system—it should be used for the main asset value on detail screens. In RTL contexts, ensure line heights are maintained to accommodate script descenders without overlapping the tight, sophisticated spacing.

## Layout & Spacing

This design system utilizes a **Fluid Grid** approach based on an 8pt rhythmic scale. 

- **Mobile:** 4-column grid with 16px margins.
- **Tablet/Desktop:** 12-column grid with 24px margins and 16px gutters.
- **Reflow Rules:** On mobile, data tables should prioritize horizontal scrolling for price columns while pinning the asset name. On desktop, sidebars are fixed to the left (or right in RTL) to provide constant access to the portfolio overview.
- **Safe Areas:** Implement strict padding for system status bars and gesture navigation zones on mobile to maintain the "full-bleed" premium look without utility interference.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Glassmorphism**. 

- **Base Layer:** The Deep Navy (#0F172A) serves as the "floor" of the application.
- **Container Layer:** Cards and sections use Charcoal Navy (#1E293B). This subtle shift in value creates depth without the need for heavy shadows.
- **Glassmorphism:** Navigation bars and sticky headers use a 20px backdrop blur with a 10% white tint. This allows the dark background colors to bleed through, maintaining a sense of place.
- **Accent Elevation:** High-priority modals feature a 1px border in Gold (#D4AF37). Ambient shadows are used sparingly; when applied, they are large-radius (24px) and very low opacity (25% black) to simulate a soft glow rather than a hard drop.

## Shapes

The shape language is structured and professional, using **Rounded** corners (0.5rem base) to soften the technical nature of the data. 

- **Small Components:** Checkboxes and utility icons use a 4px (0.25rem) radius.
- **Primary Elements:** Buttons, input fields, and main content cards use 8px (0.5rem) or 16px (1rem) for larger containers. 
- **Consistency:** Avoid pill-shaped or fully circular buttons for primary actions; stay within the defined radius scales to maintain the "institutional" character.

## Components

- **Primary Buttons:** High-contrast Gold (#D4AF37) background with Dark Navy (#0F172A) text. This is the only component that breaks the dark-on-dark theme to drive conversion.
- **Secondary Buttons:** Ghost style with a 1px Gold border and Gold text.
- **Input Fields:** Filled style using the Charcoal Navy background. On focus, the border transitions to a 2px Gold stroke with a subtle outer glow.
- **Data Cards:** 1px subtle stroke in Charcoal Navy to define boundaries. Use a 4px left-accent border in Gold for "starred" or "premium" assets.
- **Status Indicators:** Use 8px glowing dots for "Live" status. Success Green and Error Red should include a soft outer glow (bloom) to enhance the "instrument panel" feel.
- **Selection Controls:** Checkboxes and Radio buttons use the Gold accent for the active state.
- **Lists:** High-density layout with 1px dividers in Charcoal Navy (#1E293B). Secondary text within lists must use the Muted Silver for clear distinction from the primary data.