# GOLD LIVE - Gold Price Tracking App

This project contains the high-fidelity UI design and frontend code for **GOLD LIVE**, a professional gold price tracking application.

## Screens Included:
1.  **Dashboard (`dashboard.html`):** The main interface featuring 3D pricing cards, live green pulse indicator, and breaking news ticker.
2.  **Notification Settings (`settings.html`):** User preferences for price alerts with enhanced legibility and 3D toggles.
3.  **Notification Bar (`notification-bar.html`):** A specialized dynamic component that simulates a live system notification with auto-updating prices every 4 seconds.

## Design Features:
- **3D Modern Aesthetic:** Deep shadows, glassmorphism effects, and premium gold gradients.
- **Real-time Indicators:** Blinking live status dots and price trend arrows (up/down).
- **Arabic Localization:** Full RTL support with professional financial typography.
- **Responsive Design:** Optimized for mobile viewing with a desktop-compatible notification bar preview.

## Instructions for GitHub:
1.  Create a new repository on GitHub.
2.  Upload these HTML files.
3.  (Optional) Enable **GitHub Pages** in the repository settings to host the prototype live.
