---
name: Solaris Gold
colors:
  surface: '#fff9ef'
  surface-dim: '#e1d9c7'
  surface-bright: '#fff9ef'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf3e0'
  surface-container: '#f6edda'
  surface-container-high: '#f0e7d5'
  surface-container-highest: '#eae2cf'
  on-surface: '#1f1b10'
  on-surface-variant: '#4d4732'
  inverse-surface: '#343024'
  inverse-on-surface: '#f9f0dd'
  outline: '#7e775f'
  outline-variant: '#d0c6ab'
  surface-tint: '#705d00'
  primary: '#705d00'
  on-primary: '#ffffff'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#e9c400'
  secondary: '#455f88'
  on-secondary: '#ffffff'
  secondary-container: '#b6d0ff'
  on-secondary-container: '#3f5882'
  tertiary: '#5f5f59'
  on-tertiary: '#ffffff'
  tertiary-container: '#dbdad2'
  on-tertiary-container: '#5f5f59'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#adc7f7'
  on-secondary-fixed: '#001b3c'
  on-secondary-fixed-variant: '#2d476f'
  tertiary-fixed: '#e4e3db'
  tertiary-fixed-dim: '#c8c7bf'
  on-tertiary-fixed: '#1b1c17'
  on-tertiary-fixed-variant: '#474742'
  background: '#fff9ef'
  on-background: '#1f1b10'
  surface-variant: '#eae2cf'
typography:
  display-lg:
    fontFamily: IBM Plex Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin-mobile: 20px
  container-margin-desktop: 64px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is engineered to transform the typically cold, analytical world of precious metals into an experience that feels both celebratory and secure. It targets a modern investor who values clarity, optimism, and prestige.

The visual direction is **Modern-Tactile with Glassmorphic accents**. This style combines the cleanliness of high-end SaaS with the physical warmth of gold. It utilizes heavy whitespace, vibrant highlights, and translucent layers to create a sense of lightness and "air," ensuring the interface never feels cluttered or overwhelming. The emotional goal is to evoke "Confidence through Brilliance."

## Colors

The palette revolves around the interplay between the "Warm Sunlight" primary and the "Deep Navy" secondary.

- **Primary (Warm Sunlight):** Used for primary actions, success states, and value-up indicators. It should be applied with high saturation to maintain energy.
- **Secondary (Deep Navy):** Provides the professional anchor. Use this for text, navigation bars, and heavy-weight headers to ensure the app feels rooted in financial stability.
- **Surface (Creamy Shell):** The background is not a sterile white but a warm off-white, reducing eye strain and making the gold tones pop without feeling harsh.
- **Accents:** Success Green and Alert Red are strictly reserved for market movements and critical feedback loops.

## Typography

This design system utilizes **IBM Plex Sans** (with Arabic support) to maintain a technical yet humanistic feel. 

- **Weight Strategy:** Use Bold (700) for currency amounts and primary headings to emphasize growth and value. Use Medium (500) for labels to maintain legibility against colored backgrounds.
- **Numbers:** Since this is a financial app, tabular lining figures should be used if the font variant allows, ensuring that price columns align perfectly.
- **Hierarchy:** Display sizes are reserved for "Total Portfolio Value" screens. Standard interaction headers should use the Title-MD level.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a soft 8px rhythm. 

- **Mobile:** A 4-column grid with 20px margins. Content cards should span the full width of the grid to maximize readability of financial charts.
- **Desktop:** A 12-column centered grid (max-width 1280px) with 64px margins. 
- **Rhythm:** Vertical spacing between cards and sections should be generous (32px) to allow the UI to breathe, reinforcing the high-end, uncluttered brand personality.

## Elevation & Depth

To achieve a premium, joyful atmosphere, depth is created through **Soft Glassmorphism** and **Ambient Tonal Shadows**.

- **Surfaces:** Primary cards use a solid "Creamy Shell" fill, but overlays (modals, bottom sheets, navigation bars) utilize a backdrop-blur (20px) with a semi-transparent white fill (80% opacity).
- **Shadows:** Avoid pure black shadows. Use a "Deep Navy" tint for shadows with high diffusion (30-40px blur) and low opacity (5-8%). This makes elements appear to float gently above the surface rather than sitting heavily on it.
- **Lighting:** A subtle 1px inner-top border (white, 50% opacity) on buttons and cards simulates a top-down light source, adding a tactile "physical" quality to the UI elements.

## Shapes

The design system employs a **Rounded** shape language to appear approachable and modern.

- **Base Radius:** 12px (rounded-md) for standard inputs and small cards.
- **Large Radius:** 24px (rounded-lg) for main portfolio containers and modal sheets.
- **Pill Radius:** Used exclusively for interactive Chips and "Add Transaction" buttons to distinguish them from informational containers.

## Components

### Buttons
- **Primary:** Warm Sunlight (#FFD700) background with Deep Navy text. Bold weight. No border.
- **Secondary:** Deep Navy background with white text. Used for less frequent but important actions.
- **Ghost:** Transparent background with a 1.5px Deep Navy stroke.

### Cards
- **Portfolio Card:** Features a subtle gradient from Warm Sunlight to a slightly lighter gold. Includes a glassmorphic layer for the "Percentage Change" indicator to pop.
- **List Items:** Separated by whitespace rather than lines. Each item sits on a soft-rounded container with a subtle ambient shadow on hover.

### Inputs
- **Financial Inputs:** Large font sizes for currency entry. The focus state uses a 2px Warm Sunlight border and a soft outer glow.
- **Labels:** Always placed above the input in the Label-SM style (uppercase, Deep Navy 70% opacity).

### Chips & Tags
- **Trend Tags:** Pill-shaped with a light tint of the status color (e.g., 10% Success Green) and a dark version of that color for the text and icon.

### Additional Components
- **Price Charts:** Use a smooth Bezier curve for the line. Fill the area beneath the line with a subtle Sunlight Yellow gradient that fades to 0% opacity.
- **Progress Bars:** Use thick, rounded bars (12px height) to show gold weight goals.