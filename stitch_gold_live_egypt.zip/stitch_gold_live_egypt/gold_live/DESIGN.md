---
name: Gold Live
colors:
  surface: '#fcf8fa'
  surface-dim: '#dcd9db'
  surface-bright: '#fcf8fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7e9'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#45464d'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#271901'
  on-tertiary-container: '#98805d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#fcdeb5'
  tertiary-fixed-dim: '#dec29a'
  on-tertiary-fixed: '#271901'
  on-tertiary-fixed-variant: '#574425'
  background: '#fcf8fa'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display-price:
    fontFamily: IBM Plex Sans
    fontSize: 42px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  baseline: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  margin-mobile: 16px
  margin-desktop: 24px
  gutter: 12px
---

## Brand & Style
The design system for this financial platform is rooted in a **Modern-Corporate** aesthetic with **Tactile/Premium** accents. It balances the gravity of wealth management with the agility of live data. The interface must feel authoritative and secure, utilizing heavy whitespace and a refined color palette to evoke a high-value, bespoke banking experience.

The target audience is high-net-worth individuals and professional traders who require clarity, speed, and a sense of exclusivity. The UI avoids unnecessary ornamentation, focusing instead on precision, clean lines, and subtle "gold-leaf" accents to signify premium status.

## Colors
The palette is dominated by **Dark Navy** and **Cream**, a combination that suggests heritage and sophistication. 
- **Primary & Secondary:** Used for high-level structural elements like headers, bottom navigation, and primary action buttons.
- **Accent & Highlight:** Gold is used sparingly for active states, key financial indicators, and premium CTAs.
- **Functional Colors:** Emerald and Ruby are used strictly for market trends (up/down) and system statuses.
- **Surface Strategy:** Use the Cream background for the main canvas, and Deep Slate for cards or containers that require high contrast and focus.

## Typography
This design system utilizes **IBM Plex Sans** for its exceptional technical clarity and robust Arabic support. For RTL (Arabic) contexts, the typeface maintains professional geometry. 

**Price Display:** Use "display-price" for primary asset values. These should always be bold and utilize tabular lining figures to ensure numbers align perfectly in lists.
**RTL Considerations:** Line heights are slightly increased for Arabic scripts to accommodate descenders and ascenders without crowding. All text alignment is right-justified by default.

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for Android viewports.
- **Mobile:** A 4-column grid with 16px side margins.
- **Tablet:** An 8-column grid with 24px side margins.
- **Rhythm:** An 8pt spacing system governs all spatial relationships. 
- **Safe Areas:** Headers must strictly observe the Android status bar height (typically 24dp-32dp) to prevent overlap with system icons. Elements should be mirrored for RTL: Sidebars appear from the right, and "Back" arrows point right.

## Elevation & Depth
Hierarchy is established through **Tonal Layering** and **Ambient Shadows**. 
1. **Level 0 (Background):** The Cream surface (#FBF3D5).
2. **Level 1 (Cards):** Pure white or Deep Slate surfaces with a very soft, 12% opacity Navy shadow.
3. **Level 2 (Modals/Popups):** Higher elevation with a 20% opacity shadow and a 1px Gold (#D4AF37) border to signify "Premium" interaction.

**Glassmorphism:** Use sparingly for the Bottom Navigation Bar—a background blur (20px) over the cream background creates a modern, layered feel without sacrificing legibility.

## Shapes
The shape language is **Soft** and structured. A 0.25rem (4px) base radius is used for small components like checkboxes and input fields. For primary cards and buttons, use `rounded-lg` (8px) to provide a professional yet approachable feel. Avoid pill-shaped elements for financial data to maintain a serious, "instrument-panel" look.

## Components
- **Premium Cards:** Feature a subtle 1px inner stroke of #D4AF37 (Gold). When used on Dark Navy backgrounds, the card surface should be Deep Slate.
- **Live Indicators:** A 8px circular dot using the Success Emerald. Apply a pulse animation (opacity 1.0 to 0.4) to indicate real-time data streaming.
- **Data Tables:** High-density rows with 1px horizontal dividers in #E2E8F0. The "Price" column should be right-aligned (in LTR) or left-aligned (in RTL) to ensure numerical alignment.
- **Toggle Buttons:** Use the Android M3 switch style. The "On" state should use the Gold accent color for the track.
- **Input Fields:** Outlined style with a 1px Dark Navy border. On focus, the border thickens to 2px and changes to Gold.
- **Buttons:**
    - *Primary:* Dark Navy background, Gold text, 8px corner radius.
    - *Secondary:* Transparent background, 1px Gold border, Gold text.