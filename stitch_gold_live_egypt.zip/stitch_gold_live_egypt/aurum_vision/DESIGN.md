---
name: Aurum Vision
colors:
  surface: '#111318'
  surface-dim: '#111318'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#d5c4ac'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#9d8f79'
  outline-variant: '#504533'
  surface-tint: '#ffbb1e'
  primary: '#ffdb9f'
  on-primary: '#412d00'
  primary-container: '#fdb813'
  on-primary-container: '#6b4b00'
  inverse-primary: '#7c5800'
  secondary: '#f7bd48'
  on-secondary: '#412d00'
  secondary-container: '#ba880f'
  on-secondary-container: '#392700'
  tertiary: '#ffdf5d'
  on-tertiary: '#3a3000'
  tertiary-container: '#e6c200'
  on-tertiary-container: '#605000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#ffbb1e'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#ffdea6'
  secondary-fixed-dim: '#f7bd48'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5d4200'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#111318'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  display-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  element-gap: 12px
---

## Brand & Style
The design system embodies "Digital Alchemy"—a fusion of high-end luxury and futuristic financial technology. It is tailored for investors and traders who demand a sense of weight, value, and precision.

The aesthetic is **Tactile Neumorphism mixed with Glassmorphism**. UI elements are treated as physical objects carved from obsidian and plated in gold. By utilizing deep shadows, inner glows, and multi-layered translucent surfaces, the interface achieves a "hyper-3D" look that feels both futuristic and substantially expensive. The emotional response should be one of confidence, prestige, and technological edge.

## Colors
The palette is rooted in a deep "Obsidian Navy" base to allow gold elements to achieve maximum luminescence.

- **Primary Gold (#FDB813):** Used for interactive states and primary brand elements.
- **Antique Gold (#B8860B):** Used for deep shadows within gradients and secondary accents.
- **Liquid Gold (#FFD700):** Reserved for high-light points, "glowing" status indicators, and active text.
- **Obsidian Base (#0A0C10):** The foundational background color.
- **Elevation Tones:** Use `#161B22` for raised surfaces and `#050608` for recessed areas or deep shadows.

## Typography
The system utilizes **IBM Plex Sans Arabic** to provide a technical yet sophisticated reading experience. 

Headlines should utilize "Gold Leaf" gradients or high-contrast yellow to stand out against dark backgrounds. Display sizes for gold prices should be extra bold with slight letter-spacing reduction to feel compact and impactful. For body text, use a slightly desaturated gold or off-white to maintain readability without breaking the dark luxury aesthetic.

## Layout & Spacing
The layout follows a **Fluid Grid** model with significant breathing room to emphasize the 3D depth of individual modules. 

- **Desktop:** 12-column grid with 24px gutters.
- **Mobile:** 4-column grid with 16px margins.
- **Rhythm:** All spacing is based on an 8px base unit. 
- **Depth-First Spacing:** Elements with heavy shadows require at least 12px of internal padding to prevent visual "crowding" of the shadow-fall areas.

## Elevation & Depth
Elevation is the core of this design system. We use a "Light from Top-Left" logic (135 degrees).

1.  **Raised Surfaces (Extruded):** Use two shadows. A light shadow (top-left) in `#1C2128` and a dark shadow (bottom-right) in `#010101`.
2.  **Recessed Surfaces (Inverted/Pressed):** Use inner shadows to create the effect of the UI being carved into the obsidian background.
3.  **Glass Layers:** Use a 20% opacity white border (0.5px) and a backdrop blur of 20px to simulate "Gold-Tinted Glass" overlays.
4.  **Glows:** Primary elements use an outer blur of `Primary Gold` with a spread of 10-20px to indicate "energy" or active status.

## Shapes
Surfaces use a **Rounded (0.5rem to 1.5rem)** logic. 

- **Cards:** 1.5rem (`rounded-xl`) to give a smooth, pebble-like feel.
- **Inputs/Buttons:** 0.75rem (`rounded-lg`) for a more precise, mechanical feel.
- **Status Indicators:** Fully circular (pill-shaped) to represent "pips" of light.
- **Back Buttons:** Circular housings with a recessed (sunken) 3D effect.

## Components

### 3D Cards
Cards feature a subtle linear gradient background (Top-left: `#161B22` to Bottom-right: `#0A0C10`). Apply a 1px border with a "Gold-to-Transparent" linear gradient to highlight the top-left edge.

### Tactile Buttons
Primary buttons are "Liquid Gold." They feature an inner highlight on the top edge and a heavy 8px drop shadow. On "Press," the button should appear to sink into the UI by removing the drop shadow and adding an inner shadow.

### Inputs
Search and value inputs are "Recessed." Use a dark inner shadow to create a trough-like appearance. The text cursor and active borders should use the `#FFD700` glow.

### Status Indicators
Glowing dots. Use a radial gradient from `#FFD700` to transparent. For price increases, use an emerald-tinted gold; for decreases, a copper-tinted gold.

### Back Button (Settings Pattern)
The back button is housed in a circular, recessed "well." The icon itself (chevron) is rendered in `Primary Gold` with a small drop shadow to make it appear as if it is floating inside the recessed circle.

### Price Tickers
Large-scale numbers with high-contrast yellow. Use a slight "Inner Glow" on the typography to make the numbers appear like glowing filaments in a high-tech display.