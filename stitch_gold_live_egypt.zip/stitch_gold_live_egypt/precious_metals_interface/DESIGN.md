---
name: Precious Metals Interface
colors:
  surface: '#fff8f0'
  surface-dim: '#efd89a'
  surface-bright: '#fff8f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff3d7'
  surface-container: '#ffedbd'
  surface-container-high: '#fee7a7'
  surface-container-highest: '#f8e1a1'
  on-surface: '#231b00'
  on-surface-variant: '#504533'
  inverse-surface: '#3c2f01'
  inverse-on-surface: '#fff0ca'
  outline: '#837560'
  outline-variant: '#d5c4ac'
  surface-tint: '#7c5800'
  primary: '#7c5800'
  on-primary: '#ffffff'
  primary-container: '#fdb813'
  on-primary-container: '#6b4b00'
  inverse-primary: '#ffbb1e'
  secondary: '#555f6c'
  on-secondary: '#ffffff'
  secondary-container: '#d6e1ef'
  on-secondary-container: '#596470'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#e3c155'
  on-tertiary-container: '#634f00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#ffbb1e'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#d9e3f2'
  secondary-fixed-dim: '#bdc7d6'
  on-secondary-fixed: '#121c27'
  on-secondary-fixed-variant: '#3e4854'
  tertiary-fixed: '#ffe084'
  tertiary-fixed-dim: '#e5c457'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#fff8f0'
  on-background: '#231b00'
  surface-variant: '#f8e1a1'
typography:
  display-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 96px
  display-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
  headline-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  label-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 12px
  margin: 16px
---

## Brand & Style

The design system is engineered for high-stakes financial environments, specifically targeting gold and precious metal trading. It conveys an aura of **prestige, immediacy, and absolute authority**. The brand personality is professional yet bold, utilizing high-contrast elements to ensure that critical market data is legible at a glance.

The visual style is a blend of **Corporate Modern** and **Bold High-Contrast**. It employs deep charcoal surfaces to provide a sophisticated foundation, allowing the "Gold" primary accents to command attention. The interface feels tactile and premium through the use of subtle gradients and distinct structural borders that define data hierarchy without unnecessary clutter. It is designed to evoke trust, stability, and wealth.

## Colors

The palette is anchored by a triad of Gold, Charcoal, and Champagne. 

- **Primary Gold**: A vibrant, saturated gold (#FDB813) used for high-importance highlights and the "Gold Standard" gradient.
- **Secondary Charcoal**: A deep, professional off-black (#212B36) used for secondary data cards and containers to create sharp contrast against the light background.
- **Background Champagne**: A soft, warm neutral (#FDE6A6) that serves as the canvas, preventing the starkness of pure white while reinforcing the gold theme.
- **The "Gold Gradient"**: A linear gradient from #FDB813 at the top to #C9930C at the bottom, mimicking the luster of a physical gold bar.

Use **Dark Mode** logic for internal card content (white text on charcoal) and **Light Mode** logic for the global scaffold.

## Typography

This design system utilizes **IBM Plex Sans Arabic** across all levels to ensure a technical, precise, and highly legible experience. 

Typography is used as a primary tool for hierarchy. Large "Display" sizes are reserved for live prices to ensure they are the first thing a user sees. Numeric data should favor medium to bold weights to maintain visibility against dark backgrounds. 

In the dark data rows, text is rendered in pure white or high-tint gray to ensure AA accessibility. For the primary Gold card, black text is used to provide the maximum possible contrast against the yellow-gold gradient.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy within a mobile-first container. 

- **Containers**: Data is grouped into distinct modules with 12px gutters.
- **Rhythm**: A 4px baseline grid governs internal padding. Use `16px` (md) for standard card padding and `12px` (sm) for dense list views.
- **Data Rows**: Financial lists utilize a horizontal flex layout where labels are right-aligned (for Arabic RTL support) and values are center-to-left aligned.
- **Safe Areas**: Top and bottom margins are generous (24px+) to separate system status bars and navigation from the core pricing data.

## Elevation & Depth

Hierarchy is achieved through **Bold Borders** and **Tonal Layering** rather than traditional shadows. 

1. **Surface 0**: The Champagne background (#FDE6A6).
2. **Surface 1 (Primary)**: The Gold Gradient card. It uses a 1.5px solid black border to "pop" from the background.
3. **Surface 2 (Secondary)**: Dark Charcoal containers. These use subtle 1px borders in a slightly lighter gray or pure black to define their boundaries.
4. **Interactive Depth**: Buttons and cards do not use shadows; instead, they use high-contrast border-color shifts or inner-glows to indicate state changes.

## Shapes

The shape language is consistently **Rounded** to soften the high-contrast professional look, making the app feel modern and approachable despite its "heavy" financial data.

- **Standard Cards**: 1.5rem (24px) corner radius to create a friendly, containerized look.
- **Data Rows / Strips**: 0.75rem (12px) corner radius.
- **Small Elements (Chips/Badges)**: 0.5rem (8px) corner radius.
- **Icons**: Contained within circular or heavily rounded square frames.

## Components

### Cards
- **Hero Price Card**: Feature a linear gold gradient, 2px black border, and 24px corner radius. Central price text should use `display-lg`.
- **Secondary Data Cards**: Deep charcoal background, white text, 12px corner radius. Used for top-level global market rates.

### Data Rows
- **Market Strips**: Horizontal bars with a dark charcoal fill. 
- **Indicators**: Trend arrows (up/down) should use the `success_color` (vibrant green) or a bright red, set at 45-degree angles for clarity.
- **Columns**: Labels on the right, purchase price in the middle, and sale price on the left.

### Navigation
- **Bottom Bar**: A persistent bar using a gold-tinted frosted glass effect or a solid gold gradient. Icons should be charcoal and accompanied by active-state indicators (dots).

### Inputs & Buttons
- **Action Buttons**: Solid black with white text for maximum secondary prominence, or solid gold with black text for primary "Buy/Sell" actions.